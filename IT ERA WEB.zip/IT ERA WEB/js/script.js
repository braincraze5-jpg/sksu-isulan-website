// Wait for the entire HTML document to be fully loaded and parsed.
document.addEventListener('DOMContentLoaded', function() {
    
    // Find the mobile menu button (the hamburger icon) by its ID.
    const mobileMenu = document.getElementById('mobile-menu');
    
    // Find the navigation list element by its class.
    const navList = document.querySelector('.nav-list');

    // Check if both the menu button and the navigation list exist on the page to prevent errors.
    if (mobileMenu && navList) {
        
        // Add a 'click' event listener to the mobile menu button.
        mobileMenu.addEventListener('click', () => {
            
            // When the button is clicked, toggle the 'active' class on the navigation list.
            // This class is used in the CSS to show or hide the menu on smaller screens.
            navList.classList.toggle('active');
        });
    }
});

